
#include "stdio.h"
#include "biglog.h"

// nFlag = 1 追加的方式打开，0表示重新写入的方式打开,nFlag =2:从零读取的方式打开
void gamelog::WriteLog(char *pszFileName, char *pszBuffer, int nFlag)
{
    FILE *fp = NULL;
    if (nFlag == 1) {
        fp = fopen(pszFileName, "a+");
    } else if (nFlag == 2) {
        fp = fopen(pszFileName, "r+");
    } else {
        fp = fopen(pszFileName, "w+");
    }
    if (fp) {
        fprintf(fp, "%s\n", pszBuffer);
        fclose(fp);
    } else {
        printf("Open file %s failed!\n", pszFileName);
    }

}
